./steamtinkerlaunch ansg -an=Stray -ep=/home/deck/Downloads/Stray/Stray/Hk_project/Binaries/Win64/Stray-Win64-Shipping.exe
